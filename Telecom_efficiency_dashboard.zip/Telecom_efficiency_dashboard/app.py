from flask import Flask, render_template, jsonify
import json
import os

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/data')
def get_main_data():
    with open('data/processed_data.json') as f:
        return jsonify(json.load(f))

@app.route('/ticket_counts')
def get_ticket_counts():
    with open('data/ticket_counts.json') as f:
        return jsonify(json.load(f))

@app.route('/monthly_trends')
def get_monthly_trends():
    with open('data/monthly_trends.json') as f:
        return jsonify(json.load(f))

if __name__ == '__main__':
    app.run(debug=True)
